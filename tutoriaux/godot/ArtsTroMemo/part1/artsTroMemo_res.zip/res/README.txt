Ces images ont �t� cr�es pour le tutoriel 
http://lesartstronautes.bbconcept.net/t1198-godot-0003-artstromemo-partie-1-2d-gdscript

A partir de ressource cr�er par Tr�fle @ http://lesartstronautes.bbconcept.net
Reproduction interdite.
